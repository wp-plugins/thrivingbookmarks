ThrivingBookmarks, social bookmarks widget for WordPress
version 1 (Feb2010)
by: Daniel Raftery (@ThrivingKings - http://ThrivingKings.com)

To Install:

1. Upload ThrivingBookmarks.php to your /wp-content/plugins/ directory

2. Make a new folder in the root directory of your site titled "img" and upload the 3 icons of your choice to this folder. You can mix and match or upload your own, the only requirement is that they are named "fb.png" for Facebook, "rss.png" for the RSS feed, and "twitter.png" for Twitter

3. Activate the plugin from your WP dashboard.

4. Reload your homepage, then visit your Widgets section of your dashboard to organize location and change settings.

Options:

List type formats the images and links into a standard list format -
 <ul>
  <li> </li>
 </ul>

Whereas the stack format is simple one after another -
 <a href><img /></a> <a href><img /></a>

If you have any problems or suggestions, please visit the widget homepage at
http://ThrivingKings.com/ThrivingBookmarks-social-bookmarks-wp-plugin/

Cheers and enjoy!
Daniel

Hand drawn icons courtesy of TheG-Force (http://theg-force.deviantart.com/)

Handycons 2 courtesy of Janko (http://www.jankoatwarpspeed.com/post/2009/02/23/Handycons-2-another-free-hand-drawn-icon-set.aspx) 
